import{p as e}from"./index-mYFzc5-v.js";const s=t=>e("/setting/detail",t),a=t=>e("/setting/update",t);export{s as g,a as u};
