import{k as r}from"./index-mYFzc5-v.js";const i=()=>r("/driver/list"),s=t=>r("/driver/get",{driverName:t});export{s as a,i as g};
